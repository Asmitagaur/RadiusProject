package com.radius.pagefactory;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;


public class PageFactory_Login {
	
	WebDriver driver;
	Logger logger =Logger.getLogger(PageFactory_Login.class);
	
	 public PageFactory_Login(WebDriver driver) {
		
		 this.driver=driver;
		 PageFactory.initElements(driver,this);
	}
	
	
	@FindBy(xpath=".//*[@type='email']")
	WebElement EmailAddressTextbox;
	
	@FindBy(xpath=".//*[@type='password']")
	WebElement PasswordTextbox;
	
	@FindBy(xpath=".//*[@type='submit']")
	WebElement LoginButton;
	
	@FindBy(xpath=".//*[@class='GoogleSignIn__StyledButton-sc-2dy3kf-0 izigjt Button-sc-12smwpy-0 gyNNPF']")
	WebElement SignInWithGoogle;	
	
	@FindBy(xpath=".//*[@class='RrcSignInBtn__StyledButton-sc-1iqdfbb-0 uzlhV Button-sc-12smwpy-0 gyNNPF']")
	WebElement SignInWithCRS;	
	
	@FindBy(xpath=".//*[@class='img-circle ng-isolate-scope']")
	WebElement ClickOnProfilepicture;
	
	
	@FindBy(xpath=".//*[@ng-click='vm.logout()']")
	WebElement ClickLogout;
	
	@FindBy(xpath="	.//*[contains(text(),'Log In')]")
	WebElement ClickLogin;

	
	public boolean isElementPresent(By by) {
		try {
			driver.findElement(by);
			return true;
		}
		catch(Exception e) {
			return false;
		}
	}
	
	public void logintoRadius(String userEmail, String userPassword) throws Exception {
		Thread.sleep(2000);
		EmailAddressTextbox.click();
		logger.info("Clicked on EmailTextbox..");
		EmailAddressTextbox.sendKeys(userEmail);
		logger.info("Entered Email address");
		Thread.sleep(2000);
		PasswordTextbox.sendKeys(userPassword);
		logger.info("Entered Password..");
		Thread.sleep(2000);
		LoginButton.click();
		logger.info("Clicked on Login button..");
	}
	
	
	public void CheckGoogleLink() {
		Boolean val =isElementPresent(By.xpath(".//*[@class='GoogleSignIn__StyledButton-sc-2dy3kf-0 izigjt Button-sc-12smwpy-0 gyNNPF']"));
		Assert.assertTrue(val);
		logger.info("The Googlelogin  hyper link is present....");
	}
	
	
	public void CheckCRSLink() {
		Boolean val =isElementPresent(By.xpath(".//*[@class='RrcSignInBtn__StyledButton-sc-1iqdfbb-0 uzlhV Button-sc-12smwpy-0 gyNNPF']"));
		Assert.assertTrue(val);
		logger.info("The CRS login hyper link is present....");
	}
	
	public void CheckSignUplink() {
		Boolean val =isElementPresent(By.xpath(".//*[contains(text(),'Sign Up')]"));
		Assert.assertTrue(val);
		logger.info("The SignUp hyper link is present....");
	}
	public void ForgotPasswordlink() {
		Boolean val =isElementPresent(By.xpath(".//*[@class='Login__ForgotPassword-l0cx5q-3 kOHdrh']"));
		Assert.assertTrue(val);
		logger.info("The Forgot Password hyper link is present....");
	}
	
	public void gotoLoginPage() throws Exception {
		
	Thread.sleep(3000);
	ClickOnProfilepicture.click();
	Thread.sleep(4000);
	ClickLogout.click();
	logger.info("Clicked on Logout");
	Thread.sleep(4000);
	ClickLogin.click();
	logger.info("Clicked on Login");
	}
	
	
	
	
	
	
}
