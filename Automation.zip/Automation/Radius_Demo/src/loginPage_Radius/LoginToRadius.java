package loginPage_Radius;



import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.apache.log4j.xml.DOMConfigurator;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.radius.pagefactory.PageFactory_Login;
import com.thoughtworks.selenium.webdriven.commands.IsElementPresent;

import genericLibraries.LoginUsingEmail;
import genericLibraries.Property_File_Reader;



public class LoginToRadius {

	WebDriver driver;
	PageFactory_Login objLogin;
	WebDriverWait wait;
	Logger logger=Logger.getLogger(LoginToRadius.class);
	LoginUsingEmail obj_ELogin;
	public static String Chromepath=Property_File_Reader.getProperty("CHROMEPATH");
	public static String RadiusUserName=Property_File_Reader.getProperty("RadiusUserName");
	public static String RadiusPassword=Property_File_Reader.getProperty("RadiusPassword");
	
	
	@BeforeClass
	public void  Setup() {
	 
	 DOMConfigurator.configure("log4j.xml");
	 System.setProperty("webdriver.chrome.driver",Chromepath);
	 driver=new ChromeDriver();
	 driver.manage().window().maximize();
	 driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
	 logger.info("Chrome is opening.....");
	 PropertyConfigurator.configure("Log4j.properties");
 }

	@Test(priority=1,enabled=true)
	public void LoginToRadiusUsingEmail() throws Exception {
		objLogin =new PageFactory_Login(driver);
		obj_ELogin =new LoginUsingEmail(driver);
		try {
			obj_ELogin.LoginToApplication(RadiusUserName,RadiusPassword);
		} catch (Exception e) {
		
			throw new Exception("User could not login to Application",e);
		}
	}
	@Test(priority=2,enabled=true)
	public void GotoLogin() throws Exception {
	
		objLogin =new PageFactory_Login(driver);
		Thread.sleep(2000);
		objLogin.gotoLoginPage();
	}
	
	
	
	@Test(priority=3,enabled=true)
	public void VerifyGoogleLink() throws Exception { 
		objLogin =new PageFactory_Login(driver);
		Thread.sleep(4000);
		
		objLogin.CheckGoogleLink();
	}
	
	
	@Test(priority=4,enabled=true)
	public void VerifyCRS_link() throws Exception { 
		objLogin =new PageFactory_Login(driver);
		
		Thread.sleep(2000);
		objLogin.CheckCRSLink();
	}
	@Test(priority=5,enabled=true)
	public void VerifySignUP_link() throws Exception { 
		objLogin =new PageFactory_Login(driver);
		Thread.sleep(2000);
		objLogin.CheckSignUplink();
	}
	@Test(priority=6,enabled=true)
	public void Verify_ForgotPasswordLink() throws Exception { 
		objLogin =new PageFactory_Login(driver);
		Thread.sleep(2000);
		objLogin.ForgotPasswordlink();
	}
	
	}
