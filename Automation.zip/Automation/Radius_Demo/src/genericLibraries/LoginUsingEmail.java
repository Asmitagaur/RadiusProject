package genericLibraries;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.radius.pagefactory.PageFactory_Login;

import loginPage_Radius.LoginToRadius;

public class LoginUsingEmail {

	WebDriver driver;
	PageFactory_Login objLogin;
	WebDriverWait wait;
	Logger logger=Logger.getLogger(LoginToRadius.class);
	
	public static String LoginUrl= Property_File_Reader.getProperty("RadiusLoginUrl");
	
	public LoginUsingEmail(WebDriver driver) {
		this.driver=driver;
	}
	
	public void  LoginToApplication(String UserName, String userPassword) throws Exception {
		
		objLogin =new PageFactory_Login(driver);
		driver.get("https://radiusagent.com/login");
		objLogin.logintoRadius(UserName, userPassword);
		logger.info("User is able to login to application successfully...");
		Thread.sleep(3000);
	
}
}
