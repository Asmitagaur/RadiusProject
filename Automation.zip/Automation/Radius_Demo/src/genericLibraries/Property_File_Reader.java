package genericLibraries;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import org.apache.log4j.Logger;

public class Property_File_Reader {
	
	public static final Logger logger =Logger.getLogger(Property_File_Reader.class);
	public static Properties props =null;
	
	
	
	static {
		
		props =new Properties();
		FileInputStream fis;
		
		try {
		
		fis=new FileInputStream("Radius_Constants.properties");
		props.load(fis);
		}
		 catch (FileNotFoundException e) {
			logger.error(e.getMessage(),e);
			
		} catch (IOException e) {
			
			logger.error(e.getMessage());
		}
		
		
	}
	
	public static String getProperty(String key) {
		
		return props.getProperty(key);
	}

}
